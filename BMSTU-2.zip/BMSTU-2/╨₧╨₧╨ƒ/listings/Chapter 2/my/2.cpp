#include "iostream"
using std::cin, std::cout;

int main()
{
    cout << "Enter in farlong: ";
    int LenghInFarlong;
    cin >> LenghInFarlong;
    cout << "Length in yards: " << LenghInFarlong * 220 << "\n";
    return 0;
}