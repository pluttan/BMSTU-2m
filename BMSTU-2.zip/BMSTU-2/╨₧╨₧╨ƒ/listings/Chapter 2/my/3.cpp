#include "iostream"
using std::cout;

void ThreeBlingMice()
{
    cout << "Three bling mice\n";
}

void SeeHowTheyRun()
{
    cout << "See how they run\n";
}

int main()
{
    ThreeBlingMice();
    ThreeBlingMice();
    SeeHowTheyRun();
    SeeHowTheyRun();
}