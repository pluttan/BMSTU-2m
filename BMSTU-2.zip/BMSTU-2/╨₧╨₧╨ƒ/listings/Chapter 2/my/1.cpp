#include "iostream"
using std::cout;

int main()
{
    cout << "My name is Andrew\n";
    cout << "My home is my home\n";
    return 0;
}