#include <iostream>
using namespace std;

int main()
{
	cout << alignof(double) << endl;
	cin.get();
	return 0;
}