document
  .getElementById("js-search")
  .addEventListener("click", function (event) {
    const myInput = document.getElementById("js-search-input");
    const inputValue = myInput.value;
    if (inputValue != "") find(inputValue);
    else displaySearchedElements("Поле пусто");
  });

function displaySearchedElements(inputValue) {
  const SearchedElement = document.getElementById("js-searched");
  SearchedElement.style.display = "block";
  SearchedElement.innerHTML = inputValue;
}

function find(inputValue) {
  for (let raws of Object.keys(data)) {
    for (let lt of Object.keys(data[raws])) {
      for (let gk = 0; gk < data[raws][lt].length; gk++) {
        let gkData = data[raws][lt][gk];
        if (gkData[Object.keys(gkData)].name === inputValue) {
          displaySearchedElements(
            "Вот, что удалось найти:</br>" + Object.keys(gkData) + "</br>" + lt
          );
          return 0;
        }
      }
    }
  }
  displaySearchedElements("Ничего не найдено");
  return 0;
}

// // временный отслеживатель изменения блока, для постоянной работы поиска нужно будет исправить основной код)
// document
//   .getElementById("navbar")
//   .addEventListener("mouseout", function (event) {
//     document.getElementById("js-searched").style.display = "none";
//   });
